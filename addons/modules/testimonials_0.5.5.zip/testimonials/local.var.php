<?php
//***************************************************************************
/**
* LWCMS (Lightweight Content Mangement System)
*
* @package		LWCMS
* @author 		Christian J. Clark
* @copyright	Copyright (c) Christian J. Clark
* @license		http://www.gnu.org/licenses/gpl-2.0.txt
* @link			http://www.emonlade.net/lwcms/
**/
//***************************************************************************

//********************************************************************
//********************************************************************
// Module Settings
//********************************************************************
//********************************************************************

$mod_title = 'Testimonials';
$mod_icon_class = 'fa fa-comments-o';
$mod_ds = '';
$mod_dio_obj = 'testimonial';

