<?php

$mod_title = "MySQLi Test";

?>
