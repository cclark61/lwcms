<?php

trigger_error('This plugin has been renamed "POP_remote_conn.inc.php". Please update your code accordingly.', E_USER_DEPRECATED);
include('POP_remote_conn.inc.php');

?>